//Name: 
//Section: 
//ID: 

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TFIDFSearcher extends Searcher
{	
	public TFIDFSearcher(String docFilename) {
		super(docFilename);
		/************* YOUR CODE HERE ******************/
		Set<String> terms = new HashSet<>();
		for (Document document: documents){
			terms.addAll(document.getTokens());
		}
		int[][] vsm = new int[terms.size()][documents.size()];
		for(int i = 0; i < terms.size(); i++){
			for(int k = 0; k < documents.size(); k++){
				if(documents.get(k).getTokens().contains(terms.toArray()[0])){

				}
			}
			double idf = Math.log10()
			for(int j = 0; j < documents.size(); j++){

			}
		}


		/***********************************************/
	}
	
	@Override
	public List<SearchResult> search(String queryString, int k) {
		/************* YOUR CODE HERE ******************/

		return null;
		/***********************************************/
	}
}
