//Name: 
//Section: 
//ID: 

import java.util.*;

public class JaccardSearcher extends Searcher{

	private Set<String> q = new HashSet<>();
	private Map<Integer, Set<String>> d = new TreeMap<>();

	public JaccardSearcher(String docFilename) {
		super(docFilename);
		/************* YOUR CODE HERE ******************/

		for (Document document: documents){
			Set<String> subD = new HashSet<>();
			subD.addAll(document.getTokens());
			d.put(document.getId(), subD);
		}



		/***********************************************/
	}

	@Override
	public List<SearchResult> search(String queryString, int k) {
		/************* YOUR CODE HERE ******************/

		List<SearchResult> resultList = new ArrayList<>();
		List<SearchResult> choosedResultList = new ArrayList<>();
		List<Double> scoreList = new ArrayList<>();
		List<String> qTokens = tokenize(queryString);

		q.addAll(qTokens);
		SearchResult searchResult;

		for (int docId: d.keySet()){
			Set<String> intersect = new HashSet<>();
			Set<String> union = new HashSet<>();
			intersect.addAll(q);
			intersect.retainAll(d.get(docId));
			union.addAll(q);
			union.addAll(d.get(docId));
			double score = (double) intersect.size() / (double)union.size();
			scoreList.add(score);

			searchResult = new SearchResult(documents.get(docId - 1), score);
			resultList.add(searchResult);

		}
		Collections.sort(scoreList);
		for (int i = 0; i < k; i++){
			double max = 0;
			for (double subScore: scoreList){
				if(subScore > max){
					max = subScore;
				}
			}
			if(max == 0 && i == 0){
				return new ArrayList<>();
			}
			for(int j = 0; j < scoreList.size(); j++){
				if(scoreList.get(j) == max){
					scoreList.set(j, 0.0);
				}
			}
			for(SearchResult result: resultList){
				if(result.getScore() == max){
					choosedResultList.add(result);
					break;
				}
			}
		}

		return choosedResultList;
		/***********************************************/
	}

}
